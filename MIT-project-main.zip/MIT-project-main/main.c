#include "stm8s.h"

// --- Funkce pro ovl�d�n� TM1637 ---
void setDIO(uint8_t state);
void setCLK(uint8_t state);
void tm_start(void);
void tm_stop(void);
void tm_writeByte(uint8_t b);
void tm_displayCharacter(uint8_t pos, uint8_t character);
void delay_us(uint16_t microseconds);


// --- Deklarace pro kl�vesnici ---
void initKeypad(void);
char getKey(void);

// --- Segmentov� k�d pro ��slice ---
const uint8_t digitToSegment[] = {
    0x3F, // 0
    0x06, // 1
    0x5B, // 2
    0x4F, // 3
    0x66, // 4
    0x6D, // 5
    0x7D, // 6
    0x07, // 7
    0x7F, // 8
    0x6F  // 9
};

// --- PINY TM1637 ---
#define TM_CLK_PORT  GPIOB
#define TM_CLK_PIN   GPIO_PIN_5
#define TM_DIO_PORT  GPIOB
#define TM_DIO_PIN   GPIO_PIN_4

// --- PINY KL�VESNICE ---
#define ROW1_PIN GPIO_PIN_6  // PD6
#define ROW2_PIN GPIO_PIN_5  // PD5
#define ROW3_PIN GPIO_PIN_0  // PE0
#define ROW4_PIN GPIO_PIN_1  // PC1

#define COL1_PIN GPIO_PIN_0  // PG0
#define COL2_PIN GPIO_PIN_2  // PC2
#define COL3_PIN GPIO_PIN_3  // PC3

// Funkce pro nastaven� DIO a CLK
void setDIO(uint8_t state) {
    if (state) GPIO_WriteHigh(TM_DIO_PORT, TM_DIO_PIN);
    else GPIO_WriteLow(TM_DIO_PORT, TM_DIO_PIN);
}

void setCLK(uint8_t state) {
    if (state) GPIO_WriteHigh(TM_CLK_PORT, TM_CLK_PIN);
    else GPIO_WriteLow(TM_CLK_PORT, TM_CLK_PIN);
}

void tm_start(void) {
    setCLK(1);
    setDIO(1);
    delay_us(2);
    setDIO(0);
    delay_us(2);
    setCLK(0);
}

void tm_stop(void) {
    setCLK(0);
    delay_us(2);
    setDIO(0);
    delay_us(2);
    setCLK(1);
    delay_us(2);
    setDIO(1);
}

void tm_writeByte(uint8_t b) {
    uint8_t i;
    for (i = 0; i < 8; i++) {
        setCLK(0);
        setDIO(b & 0x01);
        delay_us(3);
        setCLK(1);
        delay_us(3);
        b >>= 1;
    }

    // ACK
    setCLK(0);
    GPIO_Init(TM_DIO_PORT, TM_DIO_PIN, GPIO_MODE_IN_FL_NO_IT); // input
    delay_us(5);
    setCLK(1);
    delay_us(5);
    setCLK(0);
    GPIO_Init(TM_DIO_PORT, TM_DIO_PIN, GPIO_MODE_OUT_PP_LOW_FAST); // back to output
}

void tm_displayCharacter(uint8_t pos, uint8_t character) {
    tm_start();
    tm_writeByte(0x40); // auto-increment mode
    tm_stop();

    tm_start();
    tm_writeByte(0xC0 | pos); // start address + position
    tm_writeByte(character);
    tm_stop();

    tm_start();
    tm_writeByte(0x88); // display ON, brightness = medium
    tm_stop();
}

void delay_us(uint16_t us) {
    uint16_t i;
    for (i = 0; i < us; i++) {
        _asm("nop"); _asm("nop"); _asm("nop"); _asm("nop");
        _asm("nop"); _asm("nop"); _asm("nop"); _asm("nop");
    }
}

void initKeypad(void) {
    // Nastaven� ��dk� jako v�stupy
    GPIO_Init(GPIOD, ROW1_PIN | ROW2_PIN, GPIO_MODE_OUT_PP_LOW_FAST);
    GPIO_Init(GPIOE, ROW3_PIN, GPIO_MODE_OUT_PP_LOW_FAST);
    GPIO_Init(GPIOC, ROW4_PIN, GPIO_MODE_OUT_PP_LOW_FAST);

    // Nastaven� sloupc� jako vstupy s pull-up rezistory
    GPIO_Init(GPIOG, COL1_PIN, GPIO_MODE_IN_PU_NO_IT);
    GPIO_Init(GPIOC, COL2_PIN | COL3_PIN, GPIO_MODE_IN_PU_NO_IT);
}

char getKey(void) {
    const char keyMap[4][3] = {
        {'1', '2', '3'},
        {'4', '5', '6'},
        {'7', '8', '9'},
        {'*', '0', '#'}
    };

    int row, col;
    char key = 0;
    uint32_t i;

    // Vynulov�n� ��dk� (nastaven� HIGH)
    GPIOD->ODR |= ROW1_PIN | ROW2_PIN;
    GPIOE->ODR |= ROW3_PIN;
    GPIOC->ODR |= ROW4_PIN;

    for (row = 0; row < 4; row++) {
        // Nastaven� aktu�ln�ho ��dku na LOW
        switch (row) {
            case 0: GPIOD->ODR &= ~ROW1_PIN; break;
            case 1: GPIOD->ODR &= ~ROW2_PIN; break;
            case 2: GPIOE->ODR &= ~ROW3_PIN; break;
            case 3: GPIOC->ODR &= ~ROW4_PIN; break;
        }

        // Kr�tk� zpo�d�n� pro stabilizaci
        for (i = 0; i < 1000; i++);

        // Kontrola sloupc�
        for (col = 0; col < 3; col++) {
            uint8_t colState = 1;

            switch (col) {
                case 0: colState = !(GPIOG->IDR & COL1_PIN); break;
                case 1: colState = !(GPIOC->IDR & COL2_PIN); break;
                case 2: colState = !(GPIOC->IDR & COL3_PIN); break;
            }

            if (colState) {
                // Zpo�d�n� pro debounce
                for (i = 0; i < 30000; i++);

                // Znovu ov��it, jestli je kl�vesa st�le stisknut�
                switch (col) {
                    case 0: colState = !(GPIOG->IDR & COL1_PIN); break;
                    case 1: colState = !(GPIOC->IDR & COL2_PIN); break;
                    case 2: colState = !(GPIOC->IDR & COL3_PIN); break;
                }

                if (colState) {
                    key = keyMap[row][col];

                    // Po�kej na uvoln�n�
                    while (1) {
                        switch (col) {
                            case 0: if (GPIOG->IDR & COL1_PIN) break;
                            case 1: if (GPIOC->IDR & COL2_PIN) break;
                            case 2: if (GPIOC->IDR & COL3_PIN) break;
                        }
                        break;
                    }

                    // Obnovit ��dek zp�t na HIGH
                    switch (row) {
                        case 0: GPIOD->ODR |= ROW1_PIN; break;
                        case 1: GPIOD->ODR |= ROW2_PIN; break;
                        case 2: GPIOE->ODR |= ROW3_PIN; break;
                        case 3: GPIOC->ODR |= ROW4_PIN; break;
                    }

                    return key;
                }
            }
        }

        // Obnovit aktu�ln� ��dek na HIGH
        switch (row) {
            case 0: GPIOD->ODR |= ROW1_PIN; break;
            case 1: GPIOD->ODR |= ROW2_PIN; break;
            case 2: GPIOE->ODR |= ROW3_PIN; break;
            case 3: GPIOC->ODR |= ROW4_PIN; break;
        }
    }

    return 0; // ��dn� kl�vesa
}




void main(void) {
    char key = 0;
    uint8_t segmentCode;
    char userInput[4] = {' ', ' ', ' ', ' '}; // Pole pro ulo�en� �ty� ��slic
    uint8_t index = 0; // Aktu�ln� index pro zad�n� ��slice
    uint8_t i;
    uint8_t keyPressed = 0; // Prom�nn� pro sledov�n� stavu kl�vesy

    // Inicializace hodinov�ho syst�mu (16 MHz)
    CLK_HSIPrescalerConfig(CLK_PRESCALER_HSIDIV1);

    // Inicializace displeje a kl�vesnice
    GPIO_Init(TM_CLK_PORT, TM_CLK_PIN, GPIO_MODE_OUT_PP_LOW_FAST);
    GPIO_Init(TM_DIO_PORT, TM_DIO_PIN, GPIO_MODE_OUT_PP_LOW_FAST);
    initKeypad();

    // Vymaz�n� displeje
    for (i = 0; i < 4; i++) {
        tm_displayCharacter(i, 0x00); // Vypnut� v�ech segment�
    }

    while (1) {
        key = getKey();

        // Pokud je stisknuta kl�vesa a je�t� nen� zpracov�na (nebylo zm��knuto ��dn� ��slo nebo u� je ��slo zobrazeno)
        if (key >= '0' && key <= '9' && index < 4 && !keyPressed) {
            userInput[index] = key;   // Ulo��me ��slo do pole
            index++;                  // Posuneme index na dal�� pozici
            keyPressed = 1;           // Ozna��me, �e kl�vesa byla stisknuta
        }

        // Zobraz�me v�dy aktu�ln� pole
        for (i = 0; i < 4; i++) {
            if (userInput[i] >= '0' && userInput[i] <= '9') {
                segmentCode = digitToSegment[userInput[i] - '0'];
            } else {
                segmentCode = 0x00;
            }
            tm_displayCharacter(i, segmentCode);
        }

        // Pokud u�ivatel zadal 4 ��slice, resetujeme
        if (index >= 4) {
            delay_us(300000); // cca 300 ms
            for (i = 0; i < 4; i++) {
                userInput[i] = ' ';
                tm_displayCharacter(i, 0x00);
            }
            index = 0;
            keyPressed = 0; // Resetujeme, aby u�ivatel mohl za��t znovu
        }

        // Pokud byla kl�vesa uvoln�na, m��eme znovu p�ijmout nov� stisk
        if (key == 0) {
            keyPressed = 0; // Kl�vesa byla uvoln�na, m��eme ji znovu zpracovat
        }
    }
}



// Debug podpora (voliteln�)
#ifdef USE_FULL_ASSERT
void assert_failed(uint8_t* file, uint32_t line) {
    while (1);
}
#endif